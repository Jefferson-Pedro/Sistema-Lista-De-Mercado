package br.com.project.appmercado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppmercadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppmercadoApplication.class, args);
	}

}
