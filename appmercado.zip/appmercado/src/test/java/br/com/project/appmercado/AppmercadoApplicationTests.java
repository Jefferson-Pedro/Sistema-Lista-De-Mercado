package br.com.project.appmercado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppmercadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
